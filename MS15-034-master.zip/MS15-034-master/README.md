This is a test POC for:
MS15-034: HTTP.sys (IIS) DoS And Possible Remote Code Execution.
By Ebrahim Hegazy @Zigoo0

To start using the tool, just create list.txt file, and add all the sites you want to test to that file.
And you are ready to go :)

the tool is written in python, if you don't have python installed, you can download it from: python.org

Once it's installed, Start the tool, enter list.txt and the tool will handle the rest :-)

Features:

1- Can scan Multiple sites.

2- Supports SSL

3- Super User Friendly :D
